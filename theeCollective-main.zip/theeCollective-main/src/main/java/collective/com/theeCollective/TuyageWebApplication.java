package collective.com.theeCollective;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TuyageWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(TuyageWebApplication.class, args);
	}

}
